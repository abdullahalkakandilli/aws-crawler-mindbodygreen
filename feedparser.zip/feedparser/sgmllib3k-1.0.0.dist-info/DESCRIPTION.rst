==================================================
sgmllib3k -- Py3k port of the old stdlib module
==================================================

sgmllib was dropped in Python 3. For those depending on it, that's somewhat infortunate. This is a quick and dirty port of this old module. I just ran 2to3 on it and published it. I don't indend to maintain it, so it might be a good idea to eventually think about finding another module to use.


